package Calculator.SimpleCalculator;

public class CalculatorDemo {
	public static void main(String[] args) {
		System.out.println("Sum of two numbers 10 and 20 is "+(new Calculator()).doAdd(10, 20));
	}

}
